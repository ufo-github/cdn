var webpack = require('webpack')
var path = require('path')
var config = require('./webpack.config.js')

