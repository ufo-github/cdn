var webpack = require('webpack')
var path = require('path')
var config = require('./webpack.config.js')
var args = require('yargs').argv

var plugins = [
	new webpack.DefinePlugin({
     __DEV__: JSON.stringify(JSON.parse( args.mock || false ))
  }),
  new webpack.optimize.UglifyJsPlugin({
    test: /(\.jsx|\.js)$/,
    compress: {
      warnings: false
    }
  })
]

config.plugins.concat(plugins)

module.exports = config

