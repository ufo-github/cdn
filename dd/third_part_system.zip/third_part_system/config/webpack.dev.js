var webpack = require('webpack')
var path = require('path')
var config = require('./webpack.config.js')

// html引入热键加载
var DevClient = 'webpack-hot-middleware/client?reload=true'

config.entry['index'].push(DevClient)

// 热加载插件
config.plugins.push(new webpack.HotModuleReplacementPlugin())

// 开发工具
config.devtool = 'cheap-source-map'

module.exports = config

