var path = require('path')
var webpack = require('webpack')
var ExtractTextPlugin = require('extract-text-webpack-plugin')
var HtmlWebpackPlugin = require('html-webpack-plugin')

var config = {
	entry: {
		index: [path.resolve(process.cwd(), 'src/main.js')],
		vendor: ['react', 'react-dom', 'react-router-dom']
	},
	output: {
		path: path.join(process.cwd(), 'dist'),
		publicPath: '/',
		filename: '[name].bundle.js'
	},
	plugins: [
		new ExtractTextPlugin('css/[name].css'),
		new HtmlWebpackPlugin({
			template: path.resolve(process.cwd(), 'src/index.html'),
			filename: 'index.html',
			inject: true
		}),
		new webpack.optimize.CommonsChunkPlugin({
       names: ['vendor', 'manifest']
    }),
	],
	module: {
		rules: [
			{
				test: /\.js$/,
				loaders: ['babel-loader']
			},
			{
				test: /\.scss$/,
				loader: ExtractTextPlugin.extract({
					use: ['css-loader', 'sass-loader'],
					fallback: 'style-loader'
				})
			},
			{
				test: /\.css$/,
				loader: ExtractTextPlugin.extract({
					use: 'css-loader',
					fallback: 'style-loader'
				})
			}
		]
	}
}

module.exports = config