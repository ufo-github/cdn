import React from 'react'
import { render } from 'react-dom'

import Root from './page/App.js'



render(<Root />, document.getElementById('root'))
