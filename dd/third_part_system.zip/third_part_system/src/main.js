import React, { PropTypes } from 'react';
import {render} from 'react-dom'
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'

import App from './router/router.js'



render(<App />, document.getElementById('root'))
