import React from 'react'
import { render } from 'react-dom'

// First we import some modules...
import { Router, Route, IndexRoute, Link, hashHistory } from 'react-router'

import Account from './account/index.js'
import Goods from './goods/index.js'
import Index from './index/index.js'
import Order from './order/index.js'
import Record from './goods/record.js'

const App = React.createClass({
  render() {
    return (
      <div>
        <h1>App</h1>
        <ul>
          <li><Link to="/">Index</Link></li>
          <li><Link to="/goods">Goods</Link></li>
          <li><Link to="/order">Order</Link></li>
          <li><Link to="/account">Account</Link></li>
        </ul>
        {this.props.children}
      </div>
    )
  }
})

const Root = React.createClass({
  render(){
    return (
      <Router history={hashHistory}>
        <Route path="/" component={App}>
          <IndexRoute component={Index} />
          <Route path="account" component={Account} />
          <Route path="goods" component={Goods} />
           <Route path="goods/record" component={Record} />
          <Route path="order" component={Order} />
        </Route>
      </Router>
    )
  }
})

export default Root