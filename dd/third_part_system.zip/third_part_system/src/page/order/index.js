import React from 'react'
class Order extends React.Component {
	render() {
		return <h1>订单页</h1>
	}
}

export default Order