import React from 'react'
class Index extends React.Component {
	render() {
		return <h1>主页面</h1>
	}
}

export default Index