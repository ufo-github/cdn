import React from 'react'

export default React.createClass({
  render() {
    return <div>ind11ex</div>
  }
})