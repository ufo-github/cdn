import React from 'react'
import {Link} from 'react-router'
import Record from './record.js'

export default React.createClass({
  render() {
    return (
    	<div>
    		<h1>good1111s</h1>
    		<Link to="/goods/record">record</Link>
    	</div>
    	)
  }
})