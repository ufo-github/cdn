import React from 'react'
import Record from './record.js'
import {Link} from 'react-router-dom'
class Goods extends React.Component {
	render() {
		return (
			<div>
				<h2>商品界面</h2>
				<div>
					<Link to="/goods/record" >去商品记录</Link>
				</div>
			</div>
		)
	}
}

export default Goods