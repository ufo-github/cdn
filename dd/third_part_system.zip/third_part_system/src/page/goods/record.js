import React from 'react'

class Record extends React.Component {
	render() {
		return <h1>操作记录</h1>
	}
}

export default Record