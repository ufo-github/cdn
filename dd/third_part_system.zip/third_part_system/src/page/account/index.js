import React from 'react'

class Account extends React.Component {
	render() {
		return <h1>账户页面</h1>
	}
}

export default Account