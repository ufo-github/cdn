import React, { PropTypes, Component } from 'react';

// 定义表格接收参数
const propTypes = {
  name: PropTypes.string,
  dataKey: PropTypes.string.isRequired,
  align: PropTypes.oneOf(['left', 'center', 'right']),
  width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  th: PropTypes.oneOfType([PropTypes.element, PropTypes.func]),
  td: PropTypes.oneOfType([
    PropTypes.element, PropTypes.func, PropTypes.oneOf([
      'int', 'float', 'percent', 'changeRate'
    ])
  ]),
};


const defaultProps = {
  align: 'left',
}

function Column() {
  return null;
}

Column.propTypes = propTypes;
Column.defaultProps = defaultProps;