import React, { PropTypes, Component } from 'react';

// 定义字段
const propTypes = {
  name: PropTypes.string,
  dataKey: PropTypes.string.isRequired,
  align: PropTypes.oneOf(['left', 'center', 'right']),
  width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  th: PropTypes.oneOfType([PropTypes.element, PropTypes.func]),
  td: PropTypes.oneOfType([PropTypes.element, PropTypes.func]),
}

// 默认对齐
const defaultProps = {
  align: 'left',
}

const Column = () => null

Column.propTypes = propTypes
Column.defaultProps = defaultProps

export default Column