import React, { PropTypes, Component } from 'react'
import Column from './Column'
import { findAllByType, isFunction } from './utils'

// table 标签参数
const propTypes = {
  // 类名
  className: PropTypes.string,
  // 数据
  data: PropTypes.arrayOf(PropTypes.object),
  // 子元素
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node,
  ]),
}

// 获取类名
const getDisplayName = (el) => (
  el && el.type && (el.type.displayName || el.type.name)
)

const hasNames = (columns) => {
  let result = false;

  for (let i = 0, len = columns.length; i < len; i++) {
    const col = columns[i];
    const { name } = col.props;
    // 如果name属性存在且不为空 则返回true 用于table中判断
    if (name && name !== '') {
      result = true;
    }
  }

  return result;
};

// 此处修改定义样式 
const getStyle = ({ width, align }) => {
  const style = {};

  if (width) {
    style.width = width;
  }
  if (align) {
    style.textAlign = align;
  }

  return style;
};

// 渲染th columns 是每行数据单独抽出来
const renderThs = (columns) => (
  columns.map((col, index) => {
    const { name, dataKey, th } = col.props;
    const props = { name, dataKey, colIndex: index };
    let content;
    let className;

    if (React.isValidElement(th)) {
      content = React.cloneElement(th, props);
      className = getDisplayName(th);
    } else if (isFunction(th)) {
      content = th(props);
      className = th.name;
    } else {
      content = name || '';
    }

    return (
      <th
        key={`th-${index}`}
        style={getStyle(col.props)}
        className={`react-table-th col-${index} col-${dataKey} ${className || ''}`}
      >
        {content}
      </th>
    );
  })
);

// 渲染td 
const renderTds = (data, entry, columns, rowIndex) => (
  columns.map((col, index) => {
    const { dataKey, td } = col.props;
    const value = entry[dataKey];
    const props = { data, rowData: entry, tdValue: value, dataKey, rowIndex, colIndex: index };

    let content;
    let className;

    if (React.isValidElement(td)) {
      // 如果td是React 元素 对其克隆
      content = React.cloneElement(td, props);
      className = getDisplayName(td);
    } else if (isFunction(td)) {
      content = td(props);
      className = td.name;
    } else {
      content = value;
    }

    return (
      <td
        key={`td-${index}`}
        style={getStyle(col.props)}
        className={`react-table-td col-${index} col-${dataKey} ${className || ''}`}
      >
        {content}  
      </td>
    );
  })
);

// 按行进行渲染
const renderRows = (data, columns) => {
  // data存在切不为空
  if (!data || !data.length) {return null;}

  return data.map((entry, index) => (
    (
      <tr key={`tr-${index}`} className="react-table-tr">
        {renderTds(data, entry, columns, index)}
      </tr>
    )
  ));
};

// table
function Table(props) {
  const { children, data, className } = props;
  const columns = findAllByType(children, Column);

  return (
    <div className={`react-table-container ${className || ''}`}>
      <table className="react-table">
        {hasNames(columns) && (
          <thead className="react-table-thead">
            <tr className="react-table-tr">
              {renderThs(columns)}
            </tr>
          </thead>
        )}
        <tbody className="react-table-tbody">
          {renderRows(data, columns)}
        </tbody>
      </table>
    </div>
  );
}

Table.propTypes = propTypes;

export default Table;
