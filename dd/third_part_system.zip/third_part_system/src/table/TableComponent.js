import React, { PropTypes } from 'react';
import {render} from 'react-dom'
import Table from './components/Table.js'
import Column from './components/Column.js'

const data = [
  {name: 'A', age: 10, stature: 120, weight: 30, res: 33},
  {name: 'B', age: 12, stature: 140, weight: 32, res: 33},
  {name: 'C', age: 11, stature: 124, weight: 31, res: 33},
  {name: 'D', age: 9, stature: 110, weight: 28, res: 33},
  {name: 'E', age: 10, stature: 118, weight: 27, res: 33},
  {name: 'F', age: 12, stature: 124, weight: 29, res: 33},
];



function TableComponents() {
  const keys = Object.keys(data[0]);
  console.log(keys)
  return (
    <Table data={data}>
      {
        keys.map(entry => (
          <Column dataKey={entry} name={entry} key={`col-${entry}`}/>
        ))
      }
    </Table>
  );
}

export default TableComponents
