import React from 'react'
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from 'react-router-dom'
import Account from '../page/account/index.js'
import Index from '../page/index/index.js'
import Order from '../page/order/index.js'
import Goods from '../page/goods/index.js'
import Record from '../page/goods/record.js'

const App = () => (
  <Router>
    <div>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/account">Account</Link></li>
        <li><Link to="/order">Order</Link></li>
        <li><Link to="/goods">Goods</Link></li>
      </ul>
      <hr/>
      <Route exact path="/" component={Index}/>
      <Route path="/account" component={Account}/>
      <Route path="/order" component={Order}/>
      <Route path="/goods" component={Goods}/>
      <Route path="/goods/record" component={Record}/>
      <Redirect from="/*" to="/" />
    </div>
  </Router>
)


export default App